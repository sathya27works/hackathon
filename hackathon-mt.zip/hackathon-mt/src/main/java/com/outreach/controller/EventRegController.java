package com.outreach.controller;


import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.outreach.event.Event;
import com.outreach.event.EventRegistration;

@RestController
public class EventRegController {
	@RequestMapping(method = RequestMethod.POST, value="/register/event", consumes="application/json", produces="application/json")
	@ResponseBody
	EventRegistration registerStudent(@RequestBody Event eventObj) {
	EventRegistration evntregreply = new EventRegistration();
	evntregreply.setEventId(eventObj.getEventId());
	evntregreply.setBaseLocation(eventObj.getBaseLocation());
	evntregreply.setArea("Saravanampatti");	
	return evntregreply;
	}

}
