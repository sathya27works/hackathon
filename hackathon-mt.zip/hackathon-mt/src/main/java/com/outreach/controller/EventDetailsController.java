package com.outreach.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.outreach.model.EventDetails;
import com.outreach.service.EventDetailService;

@RestController
@RequestMapping("/eventDetails")
public class EventDetailsController {
	@Autowired
	private EventDetailService eventDetailService;
	
	@CrossOrigin(maxAge = 3600)
	@GetMapping(value = "/{location}", produces = MediaType.APPLICATION_JSON_VALUE)
	List<EventDetails> registerStudent(@PathVariable("location") String location) {
	return eventDetailService.findByEventDetails(location);
	
	}

}