package com.outreach.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.outreach.model.Employee;
import com.outreach.service.MailNotificationService;

@RestController
public class EventMailController {
	
	@Autowired
	private MailNotificationService mailNotificationService;

	@RequestMapping(method = RequestMethod.GET, value="/register/sendmail", consumes="application/json", produces="application/json")
    public void getUserById() {
		Employee employee = new Employee();
		try {
		mailNotificationService.sendNotification(employee);
		}catch(MailException mailExcep) {
			
		}
    }

}
