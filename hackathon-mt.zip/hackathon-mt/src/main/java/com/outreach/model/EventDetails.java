package com.outreach.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="event_details")
public class EventDetails {
	
	@Id
	@Column(name="eventDetailsId")
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long eventDetailsId;

    @Column(name="beneficiaryName")
    private String beneficiaryName;
    
    @Column(name="councilName")
    private String councilName;
    
    @Column(name="project")
    private String project;
    
    @Column(name="eventCategory")
    private String eventCategory;
    
    @Column(name="eventTitle")
    private String eventTitle;
    
    @Column(name="eventDescription")
    private String eventDescription;

    @Column(name="eventDate")
    private Date eventDate;
    
    @Column(name="eventStartTime")
    private Time eventStartTime;
    
    @Column(name="eventEndTime")
    private Time eventEndTime;
    
    @Column(name="volunteersRequired")
    private Long volunteersRequired;
    
    @Column(name="pocId")
    private Long pocId;
    
    @Column(name="transportBoardingType")
    private String transportBoardingType;
    
    @Column(name="transportBoardingPoints")
    private String transportBoardingPoints;
    
    @Column(name="transportDropPoint")
    private String transportDropPoint;
    
    @Column(name="eventStatus")
    private String eventStatus;
    
    @Column(name="eventLocation")
    private String eventLocation;

	/**
	 * @return the eventDetailsId
	 */
	public Long getEventDetailsId() {
		return eventDetailsId;
	}

	/**
	 * @param eventDetailsId the eventDetailsId to set
	 */
	public void setEventDetailsId(Long eventDetailsId) {
		this.eventDetailsId = eventDetailsId;
	}

	/**
	 * @return the beneficiaryName
	 */
	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	/**
	 * @param beneficiaryName the beneficiaryName to set
	 */
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	/**
	 * @return the councilName
	 */
	public String getCouncilName() {
		return councilName;
	}

	/**
	 * @param councilName the councilName to set
	 */
	public void setCouncilName(String councilName) {
		this.councilName = councilName;
	}

	/**
	 * @return the project
	 */
	public String getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		this.project = project;
	}

	/**
	 * @return the eventCategory
	 */
	public String getEventCategory() {
		return eventCategory;
	}

	/**
	 * @param eventCategory the eventCategory to set
	 */
	public void setEventCategory(String eventCategory) {
		this.eventCategory = eventCategory;
	}

	/**
	 * @return the eventTitle
	 */
	public String getEventTitle() {
		return eventTitle;
	}

	/**
	 * @param eventTitle the eventTitle to set
	 */
	public void setEventTitle(String eventTitle) {
		this.eventTitle = eventTitle;
	}

	/**
	 * @return the eventDescription
	 */
	public String getEventDescription() {
		return eventDescription;
	}

	/**
	 * @param eventDescription the eventDescription to set
	 */
	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	/**
	 * @return the eventDate
	 */
	public Date getEventDate() {
		return eventDate;
	}

	/**
	 * @param eventDate the eventDate to set
	 */
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	/**
	 * @return the eventStartTime
	 */
	public Time getEventStartTime() {
		return eventStartTime;
	}

	/**
	 * @param eventStartTime the eventStartTime to set
	 */
	public void setEventStartTime(Time eventStartTime) {
		this.eventStartTime = eventStartTime;
	}

	/**
	 * @return the eventEndTime
	 */
	public Time getEventEndTime() {
		return eventEndTime;
	}

	/**
	 * @param eventEndTime the eventEndTime to set
	 */
	public void setEventEndTime(Time eventEndTime) {
		this.eventEndTime = eventEndTime;
	}

	/**
	 * @return the volunteersRequired
	 */
	public Long getVolunteersRequired() {
		return volunteersRequired;
	}

	/**
	 * @param volunteersRequired the volunteersRequired to set
	 */
	public void setVolunteersRequired(Long volunteersRequired) {
		this.volunteersRequired = volunteersRequired;
	}

	/**
	 * @return the pocId
	 */
	public Long getPocId() {
		return pocId;
	}

	/**
	 * @param pocId the pocId to set
	 */
	public void setPocId(Long pocId) {
		this.pocId = pocId;
	}

	/**
	 * @return the transportBoardingType
	 */
	public String getTransportBoardingType() {
		return transportBoardingType;
	}

	/**
	 * @param transportBoardingType the transportBoardingType to set
	 */
	public void setTransportBoardingType(String transportBoardingType) {
		this.transportBoardingType = transportBoardingType;
	}

	/**
	 * @return the transportBoardingPoints
	 */
	public String getTransportBoardingPoints() {
		return transportBoardingPoints;
	}

	/**
	 * @param transportBoardingPoints the transportBoardingPoints to set
	 */
	public void setTransportBoardingPoints(String transportBoardingPoints) {
		this.transportBoardingPoints = transportBoardingPoints;
	}

	/**
	 * @return the transportDropPoint
	 */
	public String getTransportDropPoint() {
		return transportDropPoint;
	}

	/**
	 * @param transportDropPoint the transportDropPoint to set
	 */
	public void setTransportDropPoint(String transportDropPoint) {
		this.transportDropPoint = transportDropPoint;
	}

	/**
	 * @return the eventStatus
	 */
	public String getEventStatus() {
		return eventStatus;
	}

	/**
	 * @param eventStatus the eventStatus to set
	 */
	public void setEventStatus(String eventStatus) {
		this.eventStatus = eventStatus;
	}

	/**
	 * @return the eventLocation
	 */
	public String getEventLocation() {
		return eventLocation;
	}

	/**
	 * @param eventLocation the eventLocation to set
	 */
	public void setEventLocation(String eventLocation) {
		this.eventLocation = eventLocation;
	}
    
}
