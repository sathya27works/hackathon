package com.outreach.service;

import java.util.List;

import com.outreach.model.EventDetails;

public interface EventDetailService {

	List<EventDetails> findByEventDetails(String eventDetailsLocation);
}
