package com.outreach.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.outreach.model.EventDetails;
import com.outreach.repository.EventDetailRepository;


@Service
public class EventDetailServiceImpl implements EventDetailService{
	
	EventDetailRepository eventDetails;
	@Autowired
	EventDetailServiceImpl(EventDetailRepository eventDetails){
		this.eventDetails=eventDetails;
	}

	@Override
	public List<EventDetails> findByEventDetails(String eventDetailsLocation) {
		return eventDetails.findByEventLocation(eventDetailsLocation);
	}

}
