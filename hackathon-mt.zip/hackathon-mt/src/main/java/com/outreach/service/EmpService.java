package com.outreach.service;

import com.outreach.model.Employee;

public interface EmpService {

	public Employee findByEmpId(Long empId);
}
