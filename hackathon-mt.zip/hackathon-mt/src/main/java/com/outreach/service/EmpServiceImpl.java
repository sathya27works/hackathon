package com.outreach.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.outreach.model.Employee;
import com.outreach.repository.EmpRepository;


@Service
public class EmpServiceImpl implements EmpService{
	
	EmpRepository empRepo;
	@Autowired
	EmpServiceImpl(EmpRepository empRepo){
		this.empRepo=empRepo;
	}
	

	@Override
	public Employee findByEmpId(Long empId) {		
		return empRepo.findByEmpId(empId);
	}

}
