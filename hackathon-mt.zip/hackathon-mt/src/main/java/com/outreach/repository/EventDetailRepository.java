package com.outreach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.outreach.model.EventDetails;

@Repository
public interface EventDetailRepository extends JpaRepository<EventDetails, String> {
	
	@Query(value = "SELECT eventDetails FROM EventDetails eventDetails WHERE eventDetails.eventLocation=?1", nativeQuery = true)
	List<EventDetails> findByEventLocation(String eventDetailsLocation);
}

