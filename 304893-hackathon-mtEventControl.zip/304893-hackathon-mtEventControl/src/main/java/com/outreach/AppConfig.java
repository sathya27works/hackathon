package com.outreach;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.outreach.repository.EventDetailRepository;

@Configuration
@ComponentScan(basePackages="com.outreach")
@EnableJpaRepositories(repositoryBaseClass = EventDetailRepository.class)
@EntityScan("com.outreach.model")
public class AppConfig {

}
