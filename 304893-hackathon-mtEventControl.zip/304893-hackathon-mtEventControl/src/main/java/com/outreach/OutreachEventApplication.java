package com.outreach;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutreachEventApplication {

	public static void main(String[] args) {
		SpringApplication.run(OutreachEventApplication.class, args);
	}

}

