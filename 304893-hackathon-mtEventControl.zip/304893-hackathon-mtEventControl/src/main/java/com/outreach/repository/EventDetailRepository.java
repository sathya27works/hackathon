package com.outreach.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.outreach.event.EventDetailVo;
import com.outreach.model.EventDetails;

@Repository
public class EventDetailRepository {
	
	@PersistenceContext
    private EntityManager entityManager;
	
	@Transactional
	public void insertWithEntityManager(EventDetailVo eventDetailVo) {
		EventDetails eventDetails = new DozerBeanMapper().map(eventDetailVo, EventDetails.class);
	    this.entityManager.persist(eventDetails);
	}
	
	
	@Transactional
	public void updateWithEntityManager(EventDetailVo eventDetailVo) {
		EventDetails eventDetails = new DozerBeanMapper().map(eventDetailVo, EventDetails.class);
	    EventDetails eventDetailsJpa = entityManager.find(EventDetails.class, 1l);
	    eventDetailsJpa.setEventDetailsId(eventDetails.getEventDetailsId());
	    eventDetailsJpa.setEventDate(eventDetails.getEventDate());
	    eventDetailsJpa.setEventLocation(eventDetails.getEventLocation());

	}
}

