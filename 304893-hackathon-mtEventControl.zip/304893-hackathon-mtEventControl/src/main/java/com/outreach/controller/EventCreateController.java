package com.outreach.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.outreach.event.EventDetailVo;
import com.outreach.service.EventDetailServiceImpl;

@RestController
@RequestMapping("/eventCreation")
public class EventCreateController {
	
	@Autowired
	private EventDetailServiceImpl eventDetailServiceImpl;
	
	@CrossOrigin(maxAge = 3600)
	@PostMapping(value = "/createEvent", produces = MediaType.APPLICATION_JSON_VALUE)
	void createEvent(@RequestBody EventDetailVo eventDetailVo) {
		eventDetailServiceImpl.createEventDetails(eventDetailVo);
	}
	
	@CrossOrigin(maxAge = 3600)
	@PostMapping(value = "/updateEvent", produces = MediaType.APPLICATION_JSON_VALUE)
	void updateEvent(@RequestBody EventDetailVo eventDetailVo) {
		eventDetailServiceImpl.updateEventDetails(eventDetailVo);
	}

}