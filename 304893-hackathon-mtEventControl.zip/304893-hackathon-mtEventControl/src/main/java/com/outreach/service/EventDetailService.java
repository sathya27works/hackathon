package com.outreach.service;

import com.outreach.event.EventDetailVo;

public interface EventDetailService {

	Long createEventDetails(EventDetailVo eventDetails);

	Long updateEventDetails(EventDetailVo eventDetails);
}
