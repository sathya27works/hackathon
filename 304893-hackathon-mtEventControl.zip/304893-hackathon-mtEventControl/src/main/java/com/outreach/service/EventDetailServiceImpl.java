package com.outreach.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.outreach.event.EventDetailVo;
import com.outreach.repository.EventDetailRepository;


@Service
public class EventDetailServiceImpl implements EventDetailService{
	
	EventDetailRepository eventDetailRepository;
	
	@Autowired
	EventDetailServiceImpl(EventDetailRepository eventDetailRepository){
		this.eventDetailRepository=eventDetailRepository;
	}

	@Override
	public Long createEventDetails(EventDetailVo eventDetailVo) {
		eventDetailRepository.insertWithEntityManager(eventDetailVo);
			return eventDetailVo.getEventDetailsId();
	}
	
	@Override
	public Long updateEventDetails(EventDetailVo eventDetailVo) {
		eventDetailRepository.updateWithEntityManager(eventDetailVo);
			return eventDetailVo.getEventDetailsId();
	}
}
