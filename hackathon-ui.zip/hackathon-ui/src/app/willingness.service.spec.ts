import { TestBed } from '@angular/core/testing';

import { WillingnessService } from './willingness.service';

describe('WillingnessService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WillingnessService = TestBed.get(WillingnessService);
    expect(service).toBeTruthy();
  });
});
