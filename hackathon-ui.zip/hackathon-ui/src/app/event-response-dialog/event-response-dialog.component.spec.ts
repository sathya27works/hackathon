import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventResponseDialogComponent } from './event-response-dialog.component';

describe('EventResponseDialogComponent', () => {
  let component: EventResponseDialogComponent;
  let fixture: ComponentFixture<EventResponseDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventResponseDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventResponseDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
