import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-event-response-dialog',
  templateUrl: './event-response-dialog.component.html',
  styleUrls: ['./event-response-dialog.component.scss']
})
export class EventResponseDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<EventResponseDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public responseData: any) { 

    }

  ngOnInit() {
  }

  responseEvent(){
    this.dialogRef.close("You have been registered for this event");
    // need to call the service
  }

}
