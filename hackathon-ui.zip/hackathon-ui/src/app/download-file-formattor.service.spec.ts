import { TestBed } from '@angular/core/testing';

import { DownloadFileFormattorService } from './download-file-formattor.service';

describe('DownloadFileFormattorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DownloadFileFormattorService = TestBed.get(DownloadFileFormattorService);
    expect(service).toBeTruthy();
  });
});
