import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventDetailsSliderComponent } from './event-details-slider.component';

describe('EventDetailsSliderComponent', () => {
  let component: EventDetailsSliderComponent;
  let fixture: ComponentFixture<EventDetailsSliderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventDetailsSliderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventDetailsSliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
