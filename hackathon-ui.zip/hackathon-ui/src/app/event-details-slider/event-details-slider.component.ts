import { Component, OnInit } from '@angular/core';
import {EventEmitter} from '@angular/core';
import {MaterializeAction} from 'angular2-materialize';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatDialog } from '@angular/material';
import { EventResponseDialogComponent } from '../event-response-dialog/event-response-dialog.component';
import { EventDialogComponent } from '../event-dialog/event-dialog.component';

@Component({
  selector: 'app-event-details-slider',
  templateUrl: './event-details-slider.component.html',
  styleUrls: ['./event-details-slider.component.scss']
})
export class EventDetailsSliderComponent implements OnInit {

  eventDetails:any[] = [];
  carouselActions:any;
  
  constructor(private httpClient: HttpClient,public dialog: MatDialog){
      let headers = new HttpHeaders();
      headers = headers.set('Content-Type', 'application/json; charset=utf-8')
                        .set('Access-Control-Allow-Origin','*');
      this.httpClient.get('http://localhost:8989/differentView/outreachEventDisplayService/eventDetails/coimbatore',{headers: headers})
      .subscribe(
        (data:any[]) => {
          // if(data.length) {
            console.log("Event loaded."); 
          console.log(data);
            this.eventDetails = data;
            this.carouselActions = new EventEmitter<string|MaterializeAction>();
          // }
        }
      )
  }
  
  ngOnInit() {
  }

  prev(){
    this.carouselActions.emit({action:"carousel",params:['prev']});
  }

  next(){
    this.carouselActions.emit({action:"carousel",params:['next']});
  }


  openDialog(event: any, id: any): void {
    const dialogRef = this.dialog.open(EventDialogComponent, {
      // width: '250px'
      data: {
        event,
        id
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      if(result != undefined){
        this.openResponseDialog(result);
      }
    });
  }

  openResponseDialog(event: any): void {
    const dialogRefResponse = this.dialog.open(EventResponseDialogComponent, {
      // width: '250px'
      data: {
        event
      }
    });

    dialogRefResponse.afterClosed().subscribe(result => {
      console.log('The dialog was closed Response');
      console.log(result);
    });
  }
  
}
