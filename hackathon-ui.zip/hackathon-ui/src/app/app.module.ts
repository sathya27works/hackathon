import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomMaterialModule } from './core/material.module';
import { OvmDashboardComponent } from './ovm-dashboard/ovm-dashboard.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminComponent } from './admin/admin.component';
import { ReportComponent } from './report/report.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { AdminWillingnessComponent } from './admin-willingness/admin-willingness.component';
import { AdminUploadEventsComponent } from './admin-upload-events/admin-upload-events.component';
import { ImageService } from './image.service';
import { EventDialogComponent } from './event-dialog/event-dialog.component';
import { EventResponseDialogComponent } from './event-response-dialog/event-response-dialog.component';
import { DownloadFileFormattorService } from './download-file-formattor.service';
import { EventDetailsSliderComponent } from './event-details-slider/event-details-slider.component';
import 'materialize-css';
import { MaterializeModule } from 'angular2-materialize';
import { HttpClientModule } from '@angular/common/http';
import { AdminEventDialogComponent, EventDetails } from './admin-event-dialog/admin-event-dialog.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    OvmDashboardComponent,
    DashboardComponent,
    AdminComponent,
    ReportComponent,
    EventDetailsComponent,
    AdminWillingnessComponent,
    AdminUploadEventsComponent,
    EventDialogComponent,
    EventResponseDialogComponent,
    EventDetailsSliderComponent,
    AdminEventDialogComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    CustomMaterialModule,
    BrowserModule, FormsModule,
    MaterializeModule,
    HttpClientModule
  ],
  entryComponents: [
    EventDialogComponent,
    EventResponseDialogComponent,
    AdminEventDialogComponent
  ],
  providers: [
    ImageService,
    DownloadFileFormattorService,
    EventDetails
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
