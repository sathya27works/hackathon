export class User {
    firstName: string;
    lastName: string;
    emailId: string;
    password: string;
}
