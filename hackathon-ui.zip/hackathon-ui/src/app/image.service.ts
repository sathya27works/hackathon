import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ImageService {

  visibleImages: any[];

  constructor() { 

  }
 
  getImages(){
    return this.visibleImages = IMAGES.slice(0);
  }

  getImage(id: string){
    return IMAGES.slice(0).find(image =>image.id ===id);
  }
}

const IMAGES = [
{id:"event1",url:"assets/img/OutreachTheme.jpg"},
{id:"event2",url:"assets/img/CoimbatoreLocation.jpg"},
{id:"event3",url:"assets/img/ChennaiLocation.jpg"},
{id:"event4",url:"assets/img/BangaloreLocation.jpg"},
{id:"event5",url:"assets/img/environmentalAwareness.jpg"},
{id:"event6",url:"assets/img/Teaching.jpg"},
{id:"event7",url:"assets/img/GiftDistribution.jpg"},
{id:"event8",url:"assets/img/oldAge.jpg"},
{id:"event9",url:"assets/img/bloodDonation.jpg"}
]