import { Component, OnInit } from '@angular/core';
import { ImageService } from '../image.service';

@Component({
  selector: 'app-ovm-dashboard',
  templateUrl: './ovm-dashboard.component.html',
  styleUrls: ['./ovm-dashboard.component.scss']
})
export class OvmDashboardComponent implements OnInit {
  
  displayImages: any[];
  outreachTheme: any;
  coimbatoreLocation: any;
  chennaiLocation: any;
  bangaloreLocation: any;
  
  constructor(private imageService: ImageService) { 
    this.displayImages = this.imageService.getImages();
    this.outreachTheme = this.imageService.getImage("event1");
    this.coimbatoreLocation = this.imageService.getImage("event2");
    this.chennaiLocation = this.imageService.getImage("event3");
    this.bangaloreLocation = this.imageService.getImage("event4");
  }
  ngOnInit() {
  }

  eventDetailsFunction(location: string){
      console.log(location);
  }
}
