import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminWillingnessComponent } from './admin-willingness.component';

describe('AdminWillingnessComponent', () => {
  let component: AdminWillingnessComponent;
  let fixture: ComponentFixture<AdminWillingnessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminWillingnessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminWillingnessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
