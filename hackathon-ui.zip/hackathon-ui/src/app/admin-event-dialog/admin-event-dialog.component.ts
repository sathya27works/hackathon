import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { DownloadFileFormattorService } from '../download-file-formattor.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Time } from '@angular/common';


export class EventDetails {
  eventDetailsId : number;
  beneficiaryName : string;
  councilName : string;
  project : string;
  eventCategory : string;
  eventTitle : string;
  eventDescription : string;
  eventDate : Date;
  eventStartTime : Time;
  eventEndTime : Time;
  volunteersRequired : string;
  pocId : string;
  transportBoardingType : string;
  transportBoardingPoints : string;
  transportDropPoint : string;
  eventStatus : string;
  eventLocation : string;
}

@Component({
  selector: 'app-admin-event-dialog',
  templateUrl: './admin-event-dialog.component.html',
  styleUrls: ['./admin-event-dialog.component.scss'],
  providers : [
    EventDetails
  ]
  
})
export class AdminEventDialogComponent implements OnInit {

  private eventDetail: EventDetails = new EventDetails();
  adminEventUpload: any;

  httpClientcreate: any;
  matDialog: any;

  constructor(public dialogRef: MatDialogRef<AdminEventDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,public downloadFileFormator: DownloadFileFormattorService,private httpClient: HttpClient,public dialog: MatDialog) { 
      this.adminEventUpload = this.downloadFileFormator.getFile("bulkEventUpload");
      this.httpClientcreate = this.httpClient;
      this.matDialog = this.dialog;
    }


  ngOnInit() {
  }

  registerEvent(){
     console.log(this.eventDetail);
      this.httpClientcreate.post('http://localhost:8083/eventCreation/createEvent',this.eventDetail)
      .subscribe(
        (data:any) => {
          console.log(data);
        }
      )
    this.dialogRef.close("Event creation is completed successfully");
  }

  updateEvent(){
    console.log(this.eventDetail);
     this.httpClientcreate.post('http://localhost:8083/eventCreation/updateEvent',this.eventDetail)
     .subscribe(
       (data:any) => {
         console.log(data);
       }
     )
   this.dialogRef.close("Details in Event are updated successfully");
 }

 uploadMultipleEvents(){}
}
