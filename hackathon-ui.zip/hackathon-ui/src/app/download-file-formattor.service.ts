import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DownloadFileFormattorService {

  downloadFiles: any[];

  constructor() { 

  }
 
  getFiles(){
    return this.downloadFiles = FILE_FORMATS.slice(0);
  }

  getFile(id: string){
    return FILE_FORMATS.slice(0).find(file =>file.id ===id);
  }
}

const FILE_FORMATS = [
{id:"eventId1",url:"assets/fileFormat/OutreachTheme.jpg"},
{id:"eventId2",url:"assets/fileFormat/CoimbatoreLocation.jpg"},
{id:"eventId3",url:"assets/fileFormat/ChennaiLocation.jpg"},
{id:"bulkEventUpload",url:"assets/fileFormat/Admin_event_bulk_upload_format.xlsx"}
]