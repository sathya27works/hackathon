import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { EventDialogComponent } from '../event-dialog/event-dialog.component';
import { EventResponseDialogComponent } from '../event-response-dialog/event-response-dialog.component';
import { AdminEventDialogComponent } from '../admin-event-dialog/admin-event-dialog.component';

@Component({
  selector: 'app-admin-upload-events',
  templateUrl: './admin-upload-events.component.html',
  styleUrls: ['./admin-upload-events.component.scss']
})
export class AdminUploadEventsComponent implements OnInit {

  constructor(public dialog: MatDialog){

  }

  ngOnInit() {
  }

  openDialog(id: any): void {
    const dialogRef = this.dialog.open(AdminEventDialogComponent, {
      width: '750px',
      data: {
        id
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      if(result != undefined){
        this.openResponseDialog(result);
      }
    });
  }

  openResponseDialog(event: any): void {
    const dialogRefResponse = this.dialog.open(EventResponseDialogComponent, {
      // width: '250px'
      data: {
        event
      }
    });

    dialogRefResponse.afterClosed().subscribe(result => {
      console.log('The dialog was closed Response');
      console.log(result);
    });
  }

}
