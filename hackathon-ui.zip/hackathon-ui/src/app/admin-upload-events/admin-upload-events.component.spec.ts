import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUploadEventsComponent } from './admin-upload-events.component';

describe('AdminUploadEventsComponent', () => {
  let component: AdminUploadEventsComponent;
  let fixture: ComponentFixture<AdminUploadEventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminUploadEventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminUploadEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
