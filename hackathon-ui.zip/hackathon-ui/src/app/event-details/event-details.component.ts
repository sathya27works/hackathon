import { Component, OnInit } from '@angular/core';
import { WillingnessService } from '../willingness.service';
import { MatDialog } from '@angular/material';
import { EventDialogComponent } from '../event-dialog/event-dialog.component';
import { EventResponseDialogComponent } from '../event-response-dialog/event-response-dialog.component';

@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.scss']
})
export class EventDetailsComponent implements OnInit {

  events: Object[];
  // @Input() availability: any;
  // @Input() willingnessLocation: any;

  // availability: any;
  // willingnessLocation: any;
  
  // constructor(willingnessService: WillingnessService) { 
  //   this.availability = willingnessService.availability;
  //   this.willingnessLocation = willingnessService.willingnessLocation;
    constructor(public dialog: MatDialog) { 
     
    this.events = [
      {
        id:"eventid1",
        title: "Environmental Awareness",
        // description: "What did the cheese say when it looked in the mirror?",
        // location: "Hello-Me (Halloumi)",
        volunteersRequired:4,
        status:"Inprogress",
        registeration:"Register",
        url:"assets/img/environmentalAwareness.jpg"
      },
      {
        id:"eventid2",
        title: "Teaching",
        // description: "What kind of cheese do you use to disguise a small horse?",
        // location: "Mask-a-pony (Mascarpone)",
        volunteersRequired:3,
        status:"Inprogress",
        registeration:"Register",
        url:"assets/img/Teaching.jpg"
      },
      {
        id:"eventid3",
        title: "Old Age",
        // description: "A kid threw a lump of cheddar at me",
        // location: "I thought ‘That’s not very mature’",
        volunteersRequired:10,
        status:"Inprogress",
        registeration:"UnRegister",
        url:"assets/img/oldAge.jpg"
      },
      {
        id:"eventid4",
        title: "Environmental Awareness",
        // description: "What did the cheese say when it looked in the mirror?",
        // location: "Hello-Me (Halloumi)",
        volunteersRequired:4,
        status:"Inprogress",
        registeration:"Register",
        url:"assets/img/environmentalAwareness.jpg"
      },
      {
        id:"eventid5",
        title: "Teaching",
        // description: "What kind of cheese do you use to disguise a small horse?",
        // location: "Mask-a-pony (Mascarpone)",
        volunteersRequired:3,
        status:"Inprogress",
        registeration:"Register",
        url:"assets/img/Teaching.jpg"
      },
      {
        id:"eventid6",
        title: "Old Age",
        // description: "A kid threw a lump of cheddar at me",
        // location: "I thought ‘That’s not very mature’",
        volunteersRequired:10,
        status:"Inprogress",
        registeration:"UnRegister",
        url:"assets/img/oldAge.jpg"
      }
    ];
    
  }

  ngOnInit() {
  }

  selfRegisterFunc(event: any){
    console.log("event"+ event.id)
  }

  showWillingnessFunc(){
    console.log("willingnessDetails")
  }

  // showWillingnessFunc(willingnessDetails: any){
  //   console.log("willingnessDetails"+willingnessDetails.availability)
  //   console.log("willingnessDetails"+willingnessDetails.willingnessLocation)
  // }

  openDialog(event: any, id: any): void {
    const dialogRef = this.dialog.open(EventDialogComponent, {
      // width: '250px'
      data: {
        event,
        id
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
      if(result != undefined){
        this.openResponseDialog(result);
      }
    });
  }

  openResponseDialog(event: any): void {
    const dialogRefResponse = this.dialog.open(EventResponseDialogComponent, {
      // width: '250px'
      data: {
        event
      }
    });

    dialogRefResponse.afterClosed().subscribe(result => {
      console.log('The dialog was closed Response');
      console.log(result);
    });
  }
}
