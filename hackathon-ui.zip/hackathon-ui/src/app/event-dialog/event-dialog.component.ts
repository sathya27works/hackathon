import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DownloadFileFormattorService } from '../download-file-formattor.service';

@Component({
  selector: 'app-event-dialog',
  templateUrl: './event-dialog.component.html',
  styleUrls: ['./event-dialog.component.scss']
})
export class EventDialogComponent implements OnInit {

  teamRegisterFileFormat: any;

  constructor(public dialogRef: MatDialogRef<EventDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,public downloadFileFormator: DownloadFileFormattorService) { 


      this.teamRegisterFileFormat = this.downloadFileFormator.getFile("eventId1");
    }

  ngOnInit() {
  }

  registerEvent(){
    this.dialogRef.close("You have been registered for this event");
    // need to call the service
  }
}
